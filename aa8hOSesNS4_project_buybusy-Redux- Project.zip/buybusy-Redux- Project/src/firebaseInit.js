// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCbWnz5U1EkyGpScnJGSAlJ1LpjAhJPfZM",
  authDomain: "busy-busy-redux-29e69.firebaseapp.com",
  projectId: "busy-busy-redux-29e69",
  storageBucket: "busy-busy-redux-29e69.appspot.com",
  messagingSenderId: "1041568582927",
  appId: "1:1041568582927:web:551d14a0903ddd1215427a"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);